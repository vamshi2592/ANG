package com.pos;

import java.text.NumberFormat;

public abstract class Observation
{
  public Observation() {}
  
  public abstract String toString(NumberFormat paramNumberFormat);
  
  public String toString()
  {
    return toString(NumberFormat.getInstance());
  }
}