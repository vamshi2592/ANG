package com.pos;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.wga.wg.util.Utility;

public enum Pos {

	SBJ("SBJ"), EVT("EVT"), DT("DT"), IN("IN"), VBD("VBD"), VBN("VBN"), VBG("VBG"), VBZ("VBZ"), OTHER("OTHER"), DT1(
			"DT1"), ESD("ESD"), WDT("WDT"), MD("MD"), RES("RES"), DOT("DOT"), VBM("VBM"), DG("DG"), NM("NM"), NNDP(
					"NNDP"), TO("TO"), MVB("MVB"), IN1("IN1"), NN("NN"), RB("RB"), MJJ("MJJ"), DGH("DGH"), IN2(
							"IN2"), ROA("ROA"), IN3("IN3"), EVH("EVH"), CC("CC"), NM1("NM1"), IN4("IN4"), NNDS(
									"NNDS"), VBN1("VBN1"), INS("INS"), EVHS("EVHS"), NMM("NMM"), VBNM("VBNM"), TDG(
											"TDG"), IN5("IN5"), DT2("DT2"), VBNS(
													"VBNS"), IN6("IN6"), JJP("JJP"), NNI("NNI"), VBGE("VBGE"), VBGC("VBGC"),
	AGENO("AGENO"), AGY("AGY"),	AGL("AGL"), AG("AG"), VBDW("VBDW");

	private String actualname;

	private Pos(String brand) {
		this.actualname = brand;
	}

	@Override
	public String toString() {
		return actualname;
	}

	private static Map<String, Pos> bmap = null;

	private static String translationFile = "";

	public static Pos fromCrpsTag(String btag) throws Exception {
		
		Properties prop = new Properties();
		Utility utility = new Utility();
		prop = utility.load();
		String path = prop.getProperty("res_location");
		translationFile = prop.getProperty("customTags");
		if (bmap == null) {
			bmap = new HashMap<String, Pos>();
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path+translationFile)));
			String ln;
			while ((ln = reader.readLine()) != null) {
				if (ln.startsWith("#")) {
					continue;
				}
				String[] cols = StringUtils.split(ln, "_");
				bmap.put(StringUtils.lowerCase(cols[0]), Pos.valueOf(cols[1]));
			}
			reader.close();
		}
		Pos pos = bmap.get(btag);
		if (pos == null) {
			return Pos.OTHER;
		}
		return pos;
	}

}
