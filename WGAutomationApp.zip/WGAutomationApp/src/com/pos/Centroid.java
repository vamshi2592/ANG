package com.pos;

import java.util.List;

public interface Centroid<O> {
    public void reevaluateAdd(O var1, List<? extends O> var2);

    public void reevaluateRemove(O var1, List<? extends O> var2);

    public double distance(O var1);
}
