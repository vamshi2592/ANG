package com.pos;

import be.ac.ulg.montefiore.run.jahmm.Opdf;

public interface OpdfFactory<D extends Opdf<?>> {
    public D factor();
}
