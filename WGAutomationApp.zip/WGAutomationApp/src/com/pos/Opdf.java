package com.pos;

import be.ac.ulg.montefiore.run.jahmm.Observation;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Collection;

public interface Opdf<O extends Observation>
extends Cloneable,
Serializable {
    public double probability(O var1);

    public O generate();

    public /* varargs */ void fit(O ... var1);

    public void fit(Collection<? extends O> var1);

    public void fit(O[] var1, double[] var2);

    public void fit(Collection<? extends O> var1, double[] var2);

    public String toString(NumberFormat var1);

    public Opdf<O> clone();
}
