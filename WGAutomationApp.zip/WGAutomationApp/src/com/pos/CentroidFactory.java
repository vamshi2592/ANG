package com.pos;

import be.ac.ulg.montefiore.run.jahmm.Centroid;

public interface CentroidFactory<O> {
    public Centroid<O> factor();
}
