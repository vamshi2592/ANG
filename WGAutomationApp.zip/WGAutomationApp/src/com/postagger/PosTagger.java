package com.postagger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.pos.Pos;
import com.posreader.PosReader;
import com.wga.wg.util.ObjectReader;
import com.wga.wg.util.Utility;

import be.ac.ulg.montefiore.run.jahmm.ForwardBackwardCalculator;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfIntegerFactory;
import be.ac.ulg.montefiore.run.jahmm.ViterbiCalculator;
import be.ac.ulg.montefiore.run.jahmm.io.HmmReader;
import be.ac.ulg.montefiore.run.jahmm.io.HmmWriter;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfIntegerReader;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfReader;
import be.ac.ulg.montefiore.run.jahmm.io.OpdfWriter;
import be.ac.ulg.montefiore.run.jahmm.toolbox.KullbackLeiblerDistanceCalculator;

public class PosTagger {

	private static final DecimalFormat OBS_FORMAT = new DecimalFormat("##.#####");

	private final Log log = LogFactory.getLog(getClass());

	Properties prop = new Properties();
	Utility utility = new Utility();

	private String dataDir;
	private String dictionaryLocation;
	private String posFileName;

	private Map<String, Integer> words = new HashMap<String, Integer>();

	public void setDataDir(String trainDataDir) {
		this.dataDir = trainDataDir;
	}

	public void setDictionaryLocation(String dictionaryLocation) {
		this.dictionaryLocation = dictionaryLocation;
	}

	public void setPosFileName(String posFileName) {
		this.posFileName = posFileName;
	}

	public Hmm<ObservationInteger> buildFromCorpus(ObjectReader input) throws Exception {
		PosReader posReader = new PosReader();
		posReader.setDataFilesLocation(dataDir);
		posReader.setWordDictionaryLocation(dictionaryLocation);
		posReader.read(input);
		int nbStates = Pos.values().length;
		OpdfIntegerFactory factory = new OpdfIntegerFactory(nbStates);
		Hmm<ObservationInteger> pos = new Hmm<ObservationInteger>(nbStates, factory);
		double[] inputWt = posReader.getInputLayer();
		for (int i = 0; i < nbStates; i++) {
			pos.setPi(i, inputWt[i]);
		}
		double[][] hiddenWt = posReader.getHiddenLayerWts();
		for (int i = 0; i < nbStates; i++) {
			for (int j = 0; j < nbStates; j++) {
				pos.setAij(i, j, hiddenWt[i][j]);
			}
		}
		double[][] confusionWt = posReader.getConfusionWts();
		for (int i = 0; i < nbStates; i++) {
			for (int j = 0; j < nbStates; j++) {
				pos.setOpdf(i, new OpdfInteger(confusionWt[i]));
			}
		}
		int seq = 0;
		for (String word : posReader.getWords()) {
			words.put(word, seq);
			seq++;
		}
		return pos;
	}

	public Hmm<ObservationInteger> buildFromPosFile() throws Exception {
		File posFile = new File(posFileName);
		if (!posFile.exists()) {
			throw new Exception("POS File: " + posFile.getName() + " does not exist");
		}
		FileReader fileReader = new FileReader(posFile);
		OpdfReader<OpdfInteger> opdfReader = new OpdfIntegerReader();
		Hmm<ObservationInteger> pos = HmmReader.read(fileReader, opdfReader);
		return pos;
	}

	public void saveToFile(Hmm<ObservationInteger> pos) throws Exception {
		FileWriter fileWriter = new FileWriter(posFileName);

		OpdfWriter<OpdfInteger> opdfWriter = new OpdfWriter<OpdfInteger>() {
			@Override
			public void write(Writer writer, OpdfInteger opdf) throws IOException {
				String s = "IntegerOPDF [";
				for (int i = 0; i < opdf.nbEntries(); i++)
					s += OBS_FORMAT.format(opdf.probability(new ObservationInteger(i))) + " ";
				writer.write(s + "]\n");
				
			}
		};
		HmmWriter.write(fileWriter, opdfWriter, pos);
		fileWriter.flush();
		fileWriter.close();
	}

	public double getObservationProbability(String sentence, Hmm<ObservationInteger> pos) throws Exception {
		String[] tokens = tokenizeSentence(sentence);
		List<ObservationInteger> observations = getObservations(tokens);

		//int a1 = observations.get(1).value;

		//if (a1 != 300) {
			ForwardBackwardCalculator fbc = new ForwardBackwardCalculator(observations, pos);
			return fbc.probability();
		//} else {
		//	return 300.00;
		//}

	}

	public String tagSentence(String sentence, Hmm<ObservationInteger> pos) throws Exception {
		String[] tokens = tokenizeSentence(sentence);
		List<ObservationInteger> observations = getObservations(tokens);
		ViterbiCalculator vc = new ViterbiCalculator(observations, pos);
		int[] ids = vc.stateSequence();
		StringBuilder tagBuilder = new StringBuilder();
		for (int i = 0; i < ids.length; i++) {
			tagBuilder.append(tokens[i]).append("/").append((Pos.values()[ids[i]]).name()).append(" ");
		}
		return tagBuilder.toString();
	}

	public Pos getMostLikelyPos(String word, String sentence, Hmm<ObservationInteger> pos) throws Exception {
		if (words == null || words.size() == 0) {
			loadWordsFromDictionary();
		}
		String[] tokens = tokenizeSentence(sentence);
		List<ObservationInteger> observations = getObservations(tokens);
		int wordPos = -1;
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i].equalsIgnoreCase(word)) {
				wordPos = i;
				break;
			}
		}
		if (wordPos == -1) {
			throw new IllegalArgumentException("Word [" + word + "] does not exist in sentence [" + sentence + "]");
		}
		ViterbiCalculator vc = new ViterbiCalculator(observations, pos);
		int[] ids = vc.stateSequence();
		return Pos.values()[ids[wordPos]];
	}

	public double difference(Hmm<ObservationInteger> posCurr, Hmm<ObservationInteger> posNxt) throws Exception {
		KullbackLeiblerDistanceCalculator kdc = new KullbackLeiblerDistanceCalculator();
		return kdc.distance(posCurr, posNxt);
	}

	String[] tokenizeSentence(String sentence) {
		String[] tokens = StringUtils.split(StringUtils.lowerCase(StringUtils.trim(sentence)), " ");
		return tokens;
	}

	List<ObservationInteger> getObservations(String[] tokens) throws Exception {
		if (words == null || words.size() == 0) {
			loadWordsFromDictionary();
		}
		List<ObservationInteger> observations = new ArrayList<ObservationInteger>();
		for (String token : tokens) {

			if (words.get(token) != null) {
				observations.add(new ObservationInteger(words.get(token)));
			} else {

				observations.add(new ObservationInteger(300)); // custom
																// observation
			}
		}
		return observations;
	}

	void loadWordsFromDictionary() throws Exception {

		prop = utility.load();

		dictionaryLocation = prop.getProperty("dictionary");
		BufferedReader reader = new BufferedReader(new FileReader(dictionaryLocation));
		String word;
		int seq = 0;
		while ((word = reader.readLine()) != null) {
			words.put(word, seq);
			seq++;
		}
		reader.close();
	}
}
