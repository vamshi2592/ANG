package com.postagger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pos.Pos;

import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfIntegerFactory;
import be.ac.ulg.montefiore.run.jahmm.learn.BaumWelchLearner;
import be.ac.ulg.montefiore.run.jahmm.learn.KMeansLearner;

public class PosLrnAlgthm {
	
	private Map<String, Integer> words = new HashMap<String, Integer>();
	
	public Hmm<ObservationInteger> learn(List<String> sentences) throws Exception {
		
		PosTagger posTagger = new PosTagger();
		if (words == null || words.size() == 0) {
			posTagger.loadWordsFromDictionary();
		}
		OpdfIntegerFactory factory = new OpdfIntegerFactory(words.size());
		List<List<ObservationInteger>> sequences = new ArrayList<List<ObservationInteger>>();
		for (String sentence : sentences) {
			List<ObservationInteger> sequence = posTagger.getObservations(posTagger.tokenizeSentence(sentence));
			sequences.add(sequence);
		}
		KMeansLearner<ObservationInteger> kml = new KMeansLearner<ObservationInteger>(Pos.values().length, factory,
				sequences);
		Hmm<ObservationInteger> pos = kml.iterate();
		
		BaumWelchLearner bwl = new BaumWelchLearner();
		Hmm<ObservationInteger> refinedPos = bwl.iterate(pos, sequences);
		return refinedPos;
	}

}
