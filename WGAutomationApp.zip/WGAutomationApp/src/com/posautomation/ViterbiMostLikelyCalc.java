package com.posautomation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

import com.pos.Pos;
import com.posreader.PosReader;
import com.wga.wg.util.Consts;
import com.wga.wg.util.ObjectReader;

public class ViterbiMostLikelyCalc {

	public ArrayList<String> viterbiSequence(ObjectReader input) throws Exception {
		
		String uIStr ="";
		int stnSpltSize = 3;		
		
		ArrayList<String> genInfoSet1Arr = new ArrayList<String>();
		genInfoSet1Arr.add(Consts.EVT_ST_DT_CONSTANT);
		genInfoSet1Arr.add(Consts.SBJ_CONSTANT);
		genInfoSet1Arr.add(Consts.EVNT_CONSTANT);
		
		ArrayList<String> medHistorySet1Arr = new ArrayList<String>();
		medHistorySet1Arr.add(Consts.EVT_HIST_ST_DT_CONSTANT);
		medHistorySet1Arr.add(Consts.ROUT_ADMN_CONSTANT);
		
		ArrayList<String> decodeArrLst = new ArrayList<String>();
		ArrayList<String> finalPosAl = new ArrayList<String>();
		
		ArrayList<String> viterbiSeq = new ArrayList<String>();
				
		
		DecodingPos dp = new DecodingPos();	
		for(int i=1; i<=stnSpltSize; i++){
			Random randomGenerator;
			if(i==stnSpltSize-1){
				
				String genInfoSet2=Consts.DRUG_CONSTANT;
				uIStr = genInfoSet2;
				
			} else if(i==stnSpltSize) {
				int medHisIndex =getRandomNumberInRange(0, medHistorySet1Arr.size()-1);
				System.out.println("medHisIndex ******"+medHisIndex);
				uIStr = medHistorySet1Arr.get(medHisIndex);
			} else {
				randomGenerator = new Random();
				int genInfoIndex = getRandomNumberInRange(0, genInfoSet1Arr.size()-1);
				System.out.println("genInfoIndex ******"+genInfoIndex);
				uIStr = genInfoSet1Arr.get(genInfoIndex);
			}
			
		String initialMtxVal = dp.getValueAt(uIStr,i);	
		//System.out.println("initialMtxVal::"+initialMtxVal);
		
		decodeArrLst = DecodingPos.decodePattern(uIStr, initialMtxVal, input);
		//System.out.println("decodeArrLst::"+decodeArrLst);
		for(String tGetVal:decodeArrLst){
			viterbiSeq.add(tGetVal);
			//System.out.println("decodeArrLst.get(i1): " + tGetVal);
		}
		finalPosAl.add(decodeArrLst.toString());
		}
		
		//System.out.println("finalPosAl: " + finalPosAl);
		System.out.println("viterbiSeq: " + viterbiSeq);
		return viterbiSeq;
	}
	
	private int getRandomNumberInRange(int min, int max) {
		
		Random r = new Random();
		return r.ints(min, (max + 1)).limit(1).findFirst().getAsInt();
		
	}
	
	public static HashMap<String, String> PosABMatrix( ObjectReader input) throws Exception {

		HashMap<String, String> nextPOSmap = new HashMap<String, String>();
		
		ArrayList<Pos> posArr = new ArrayList<Pos>();

		PosReader br = new PosReader();
		br.read2(input);

		double[][] POSMatrix = br.getHiddenLayerWts();

		Pos POSStr = null;
		int posOrdinal = 0;
		Pos nextPos = null;
		
		for (int i = 0; i < Pos.values().length; i++) {

			posArr.add(Pos.values()[i]);
			POSStr = posArr.get(posArr.size() - 1);
			posOrdinal = POSStr.ordinal();
			int maxPos = 0;
			String nextPosSet = null;
			for (int j = 0; j < Pos.values().length; j++) {
				if (POSMatrix[posOrdinal][j] > maxPos) {
					nextPos = Pos.values()[j];
					nextPosSet=nextPos.toString();
				}
			}
			nextPOSmap.put(POSStr.toString(), nextPosSet);
		}
			/*
			 * to build the A matrix to get the previous POS value
			 * 
			 * 
			 String prevPosSet = null;
			 Pos prevPos = null;
			 HashMap<String, String> prevPOSmap = new HashMap<String, String>();
			for (int j = 0; j < Pos.values().length; j++) {
				if (POSMatrix[j][posOrdinal] > maxPos) {
					prevPos = Pos.values()[j];
					prevPosSet=prevPos.toString();
				}
			}
			prevPOSmap.put(POSStr.toString(), prevPosSet);
		}
		if (POS.equals("next")){
			return nextPOSmap;
		}
		else if (POS.equals("prev")){
			return prevPOSmap;
		}
		else{
			return null;
		}*/

		System.out.println("nextPOSmap :: "+nextPOSmap);
		return nextPOSmap;
	}
	
	public static void PosAMatrix( ObjectReader input) throws Exception {

		HashMap<String, String> initPOSmap = new HashMap<String, String>();
		
		ArrayList<Pos> posArr = new ArrayList<Pos>();

		PosReader br = new PosReader();
		br.read2(input);

		double[] POSMatrix = br.getInputLayer();

		Pos POSStr = null;
		int posOrdinal = 0;
		Pos nextPos = null;
		
		int lenAMatrix = POSMatrix.length;
		//Arrays.sort(POSMatrix);
		double max = POSMatrix[0];
		for (int i = 1; i < lenAMatrix; i++) {
			if(POSMatrix[i] > max){
				max = POSMatrix[i];
			}
			else{
				
			}
			System.out.println("valAMatrix1 :: "+POSMatrix[i]);
			posArr.add(Pos.values()[i]);
			POSStr = posArr.get(posArr.size() - 1);
			posOrdinal = POSStr.ordinal();
			int maxPos = 0;
			String nextPosSet = null;
			for (int j = 0; j < Pos.values().length; j++) {
				if (POSMatrix[posOrdinal][j] > maxPos) {
					nextPos = Pos.values()[j];
					nextPosSet=nextPos.toString();
				}
			}
			initPOSmap.put(POSStr.toString(), nextPosSet);
		}

		return;
	}

	
	
}