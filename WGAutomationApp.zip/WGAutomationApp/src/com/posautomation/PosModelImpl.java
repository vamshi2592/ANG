package com.posautomation;

import java.util.ArrayList;

import org.apache.commons.lang.WordUtils;

import com.wga.wg.util.ObjectReader;


public class PosModelImpl {	
	
	public StringBuilder predict(ObjectReader input, String contextPath) throws Exception {
		StringBuilder builder = new StringBuilder();
		PosModel posModel = new PosModel();
		posModel.buildPosModel(contextPath, input);
		
		System.out.println("Model Processing Completed....");
		
		ArrayList<String> predictNextWts = posModel.predictNextWeights(input);
		builder= joinSentences(predictNextWts,input);
		
		return builder;
	}
	
	
	public StringBuilder joinSentences(ArrayList<String> predictedSentence, ObjectReader input){
		
		StringBuilder builder = new StringBuilder();
		String eventIntensity ="";
		String currentString = null;
		eventIntensity = input.getEventDrugs();
		for (String value : predictedSentence) {
			
			String nextString = value;
		        if(currentString==null){
		        	
		            currentString=nextString;
		            if(currentString.equalsIgnoreCase("diabetes")){
		            	currentString = eventIntensity + " " + input.getEvent();
					}
		            else if(currentString.equalsIgnoreCase("Cardiovascular")){
		            	currentString = eventIntensity + " " + input.getEvent();
					}
					else if(currentString.equalsIgnoreCase("morbidity")){
						currentString = eventIntensity + " " + input.getEvent();
					}
					else if(currentString.equalsIgnoreCase("kidney")){
						currentString = eventIntensity + " " + input.getEvent();
					}
		            builder.append(currentString+" ");
		            continue;
		        }
		       
				if(nextString.equalsIgnoreCase("diabetes")){
					nextString = eventIntensity + " " + input.getEvent();
				} 
				else if(nextString.equalsIgnoreCase("Cardiovascular")){
					nextString = eventIntensity + " " + input.getEvent();
				}
				else if(nextString.equalsIgnoreCase("morbidity")){
					nextString = eventIntensity + " " + input.getEvent();
				}
				else if(nextString.equalsIgnoreCase("kidney")){
					nextString = eventIntensity + " " + input.getEvent();
				}
				else if(nextString.equalsIgnoreCase("disability")){
					nextString = input.getSeriousOfEvt();
				}
				else if(nextString.equalsIgnoreCase("death")){
					nextString = input.getSeriousOfEvt();
				}
				else if(nextString.equalsIgnoreCase("prolong")){
					nextString = input.getSeriousOfEvt();
				}
				else if(nextString.equalsIgnoreCase("require")){
					nextString = input.getSeriousOfEvt();
				}
				else if(nextString.equalsIgnoreCase("oral")){
					nextString = input.getRoute() + " route of administration";
				}
				else if(nextString.equalsIgnoreCase("tube")){
					nextString = "a "+input.getRoute();
				}
		      
	            if(nextString.equalsIgnoreCase(".")){
	            	currentString = nextString;
	            }
	            else{
	            	currentString=" "+nextString;
	            }
			builder.append(currentString);
		}
		//System.out.println("builder:: "+builder);
		return builder;
	}
}
	


