package com.posautomation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.postagger.PosTagger;
import com.wga.wg.util.ObjectReader;
import com.wga.wg.util.StructureTemplate;
import com.wga.wg.util.Utility;
import com.posautomation.PosToJSON;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;

public class PosModel {

	PosTagger posTagger = new PosTagger();
	Hmm<ObservationInteger> posObj;
	
	Properties prop = new Properties();
	Utility utility = new Utility();
	
	
	private final Log log = LogFactory.getLog(getClass());

	public void init() {

		posTagger.setDataDir("/opt/brown-2.0");
		//posTagger.setDictionaryLocation("resources/wordDictionaryLocation.txt");
		prop= utility.load();
		
	}
	
	@SuppressWarnings("unused")
	public void buildPosModel(String contextPath, ObjectReader input) throws Exception {
		
		init();
		posTagger.setPosFileName(prop.getProperty("res_location")+prop.getProperty("activation_weights"));
		//build model
		Hmm<ObservationInteger> pos = posTagger.buildFromCorpus(input);
		posTagger.saveToFile(pos);

		posObj = posTagger.buildFromPosFile();

	}

	public ArrayList<String> predictNextWeights(ObjectReader input) throws Exception {
		
		ArrayList<String> nextWtsList = new ArrayList<String>();
		HashMap<String, Set<String>> crps = CreateTagsDict.posMap();
		ViterbiMostLikelyCalc vmc = new ViterbiMostLikelyCalc();
		ArrayList<String> viterbiSequence = vmc.viterbiSequence(input);
		PosToJSON.putPosInJson(viterbiSequence);
		String posCurrTagStr = "";
		String posNxtTagStr = "";

		ArrayList<String> uIPosList = new ArrayList<String>();
		ArrayList<String> uIPosListSplit = new ArrayList<String>();
		uIPosList = DecodingPos.filterNxtBestPos().get("UIPOS");
		for (int b1 = 0; b1 < uIPosList.size(); b1++) {
			String[] secParts = uIPosList.get(b1).split("\\%");
			for (int b2 = 0; b2 < secParts.length; b2++) {
				uIPosListSplit.add(secParts[b2]);
			}
		}
		
		for (int i = 0; i < viterbiSequence.size() - 1; i++) {
			
			posCurrTagStr = viterbiSequence.get(i);
			posNxtTagStr = viterbiSequence.get(i + 1);
			Set<String> posCurrSetVal = crps.get(posCurrTagStr.trim());
			Set<String> posNxtSetVal = crps.get(posNxtTagStr.trim());
			//log.info("posCurrSetVal:"+posCurrSetVal+"- posNxtSetVal::"+posNxtSetVal);

			double nextWordProb = 0.0;
			String currAndNxtWord = "";
			int a=0;

			String inputVal = "";
			if(uIPosListSplit.contains(posCurrTagStr)){	
				inputVal= getInputValue(posCurrTagStr, input);
				
				for (String sw1: posNxtSetVal){
					a++;
    				String nextWords = inputVal + " " + sw1;
    				currAndNxtWord = nextWords;
    				if(posTagger.getObservationProbability(nextWords, posObj) > nextWordProb){
    					nextWordProb = posTagger.getObservationProbability(nextWords, posObj);
    					currAndNxtWord = nextWords;
    				}
    			}
				nextWtsList.add(currAndNxtWord);
			}
			else if(uIPosListSplit.contains(posNxtTagStr)){	
				inputVal= getInputValue(posNxtTagStr, input);
				
				for (String sw1: posCurrSetVal){
					a++;
    				String nextWords = sw1 + " " + inputVal;
    				currAndNxtWord = nextWords;
    				double probVal = posTagger.getObservationProbability(nextWords, posObj);
    				
    				if(probVal != 300.0){
    				
    				if(posTagger.getObservationProbability(nextWords, posObj) > nextWordProb){
    					nextWordProb = posTagger.getObservationProbability(nextWords, posObj);
    					currAndNxtWord = nextWords;
    				}
    				
    				} 
    			}
				nextWtsList.add(currAndNxtWord);
			}
			else{
				for(String sw1: posCurrSetVal){
					for (String sw2: posNxtSetVal){
						a++;
	    				String nextWords = sw1 + " " + sw2;
	    				currAndNxtWord = nextWords;
	    				if(posTagger.getObservationProbability(nextWords, posObj) > nextWordProb){
	    					nextWordProb = posTagger.getObservationProbability(nextWords, posObj);
	    					currAndNxtWord = nextWords;
	    				}
	    			}
				}
				nextWtsList.add(currAndNxtWord);
			}
		}

        ArrayList<String> finalSentence1 = new ArrayList<String>();
        for(int x=0; x<nextWtsList.size(); x++){
	    	String word1[] = nextWtsList.get(x).split(" ");
	    	finalSentence1.add(word1[0]);
	    }
        String word1[] = nextWtsList.get(nextWtsList.size()-1).split(" ");
    	finalSentence1.add(word1[1]);
    	//System.out.println("finalSentence1:: "+finalSentence1);
		return finalSentence1;
	}
	

	public String getInputValue(String posTagStr, ObjectReader input){
		
		String inputStr= "";
		
		if(posTagStr.equals("SBJ")){
			inputStr = input.getReporter();
		}
		if(posTagStr.equals("AGENO")){
			inputStr = input.getAge();
		}
		if(posTagStr.equals("EVT")){
			inputStr = input.getEvent();
			
			if(inputStr.contains("kidney")){
				inputStr = "kidney";
			} 
			else if(inputStr.contains("diabetes")){
				inputStr = "diabetes";
			} 
			else if(inputStr.contains("morbidity")){
				inputStr = "morbidity";
			} 
			else if(inputStr.contains("Profile")){
				inputStr = "Cardiovascular";
			}
		}
		if(posTagStr.equals("ESD")){
			inputStr = input.getDate();
		}
		if(posTagStr.equals("RES")){
			inputStr = input.getSeriousOfEvt();
			
            if(inputStr.contains("death")){
				inputStr = "death";
			} 
            else if(inputStr.contains("disability")){
				inputStr = "disability";
			} 
            else if(inputStr.contains("prolong")){
				inputStr = "prolong";
			} 
            else if(inputStr.contains("require")){
				inputStr = "require";
			}
		}
		if(posTagStr.equals("DG") || posTagStr.equals("TDG") ){
			inputStr = input.getDrugname();
		}
		if(posTagStr.equals("DGH")){
			inputStr = input.getDrughistoryname();
		}
		if(posTagStr.equals("ROA")){
			inputStr = input.getRoute();
			if(inputStr.contains("tube")){
				inputStr = "tube";
			}
		}
		if(posTagStr.equals("EVH")){
			inputStr = input.getEventhistory();
		}
		if(posTagStr.equals("EVHS")){
			inputStr = input.getEventhistorydate();
		}
		return inputStr;
	}

}
