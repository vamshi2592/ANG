package com.posautomation;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import com.pos.Pos;
import com.posreader.PosReader;
import com.wga.wg.util.Consts;
import com.wga.wg.util.Utility;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import com.wga.wg.util.ObjectReader;

public class PosToJSON {

	//public static void main(String[] args) throws Exception{
	
	public static void putPosInJson(ArrayList<String> viterbiSeq) throws Exception {
		JSONArray seq1 = new JSONArray();
		int i=0;
		for(String str:viterbiSeq){
			seq1.put(i, str);
			i++;
		}
		Properties prop = new Properties();
		Utility utility = new Utility();
		prop = utility.load();		
		String posJson_Path = prop.getProperty("res_location")+prop.getProperty("pos_json");
		String jsonData = Utility.readFile(posJson_Path);
		JSONObject jobj = new JSONObject(jsonData);
		JSONArray resultArr = new JSONArray(jobj.getJSONArray("result").toString());
		int len = resultArr.length();
		ArrayList<Integer> compareSeq = new ArrayList<Integer>();
		//System.out.println("Check viterbi seq in JSON: Return 0 if present");
		//Check viterbi seq in JSON: Return 0 if present
		for(int x=0; x<len; x++){
			int a = resultArr.getJSONArray(x).toString().compareTo(seq1.toString());
			//System.out.println(a);
			compareSeq.add(a);
		}
		if(!compareSeq.contains(0)){
			resultArr.put(len, seq1);
			jobj.put("result", resultArr);
			try (FileWriter file = new FileWriter(posJson_Path)) {
				file.write(jobj.toString());
				System.out.println("Copied new JSON Object to File");
				System.out.println("\nUpdated JSON file: " + jobj);
			}
		}
	}
}