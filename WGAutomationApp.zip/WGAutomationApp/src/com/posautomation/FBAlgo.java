package com.posautomation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.postagger.PosTagger;
import com.wga.wg.util.ObjectReader;
import com.wga.wg.util.StructureTemplate;
import com.wga.wg.util.Utility;
import com.posautomation.PosToJSON;

import be.ac.ulg.montefiore.run.jahmm.ForwardBackwardCalculator;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;

public class FBAlgo {

	public double getObservationProbability(String sequence, Hmm<ObservationInteger> pos) throws Exception {
		String[] tokens = tokenizeSentence(sequence);
		List<ObservationInteger> observations = getObservations(tokens);

		//int a1 = observations.get(1).value;

		//if (a1 != 300) {
			ForwardBackwardCalculator fbc = new ForwardBackwardCalc(observations, pos);
			return fbc.probability();
		//} else {
		//	return 300.00;
		//}

	}
	public ArrayList<String> ForwardBackwardCalc(ObjectReader sequence, observations, pos) throws Exception {
		
		for (int i = 0; i < sequence.size() - 1; i++) {
			
			posCurrTagStr = sequence.get(i);
			posNxtTagStr = sequence.get(i + 1);
			Set<String> posCurrSetVal = crps.get(posCurrTagStr.trim());
			Set<String> posNxtSetVal = crps.get(posNxtTagStr.trim());
			//log.info("posCurrSetVal:"+posCurrSetVal+"- posNxtSetVal::"+posNxtSetVal);

			double nextWordProb = 0.0;
			String currAndNxtWord = "";
			int a=0;

			String inputVal = "";
			for(String sw1: posCurrSetVal){
				for (String sw2: posNxtSetVal){
					a++;
    				String nextWords = sw1 + " " + sw2;
    				currAndNxtWord = nextWords;
    				posTagger.getObservationProbability(nextWords, posObj)
    				if(posTagger.getObservationProbability(nextWords, posObj) > nextWordProb){
    					nextWordProb = posTagger.getObservationProbability(nextWords, posObj);
    					currAndNxtWord = nextWords;
    				}
    			}
			}
			nextWtsList.add(currAndNxtWord);
		}

        ArrayList<String> finalSentence1 = new ArrayList<String>();
        for(int x=0; x<nextWtsList.size(); x++){
	    	String word1[] = nextWtsList.get(x).split(" ");
	    	finalSentence1.add(word1[0]);
	    }
        String word1[] = nextWtsList.get(nextWtsList.size()-1).split(" ");
    	finalSentence1.add(word1[1]);
    	//System.out.println("finalSentence1:: "+finalSentence1);
		return finalSentence1;
	}

}
