package com.posautomation;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.wga.wg.util.Utility;

public class CreateTagsDict {

	public static HashMap<String, Set<String>> posMap() throws Exception {
		
		Properties prop = new Properties();
		Utility utility = new Utility();
		prop = utility.load();		
		String res_Path = prop.getProperty("res_location");
		
		final Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
		LOGGER.setLevel(Level.INFO);
		
		@SuppressWarnings("resource")
		
		Scanner input1 = new Scanner(new File(res_Path+prop.getProperty("tagged")));
        input1.useDelimiter(" |\n");
        
        @SuppressWarnings("resource")
		Scanner input2 = new Scanner(new File(res_Path+prop.getProperty("train_lib")));
        input2.useDelimiter(" |\n");
        
        ArrayList<String> taggedTokens = new ArrayList<String>();
        String word;
        while(input1.hasNext()) {
            word = input1.next();
            taggedTokens.add(word);
        }
        while(input2.hasNext()) {
            word = input2.next();
            taggedTokens.add(word);
        }
        
        
	     HashMap<String, Set<String>> map = new HashMap<String, Set<String>>();
	     
	     for(int i=0; i<taggedTokens.size(); i++)
	      {
	          String[] parts = taggedTokens.get(i).split("_", 2);
	          if (parts.length >= 2)
	          {
	              String key = parts[1];
	              String value = parts[0];
	              
	              boolean flag = map.containsKey(key);
	              
	              if (flag == false){
	                  Set<String> al = new HashSet<>();
	                  al.add(value);
	                  map.put(key, al);
	              }
	              else {
	                  map.get(key).add(value);
	              }
	          } 
	          else {
	          }
	      }
	     LOGGER.info(" SUCCESS:: final corpus: "+map);
	     return map;

	}

}
