package com.posautomation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import com.wga.wg.util.Consts;
import com.wga.wg.util.ObjectReader;
import com.wga.wg.util.Utility;

public class DecodingPos {

	// public static String uIStr = ""; //SBJ//ESD//EVT//DG//EVHS//ROA
	// public static String initialMtxVal = ""; //DT//INS//EVT//DT//DT//INS
	public static String hybridPos = Consts.CUSTOM_CONSTANT;
	public static ArrayList<String> decodePattern(String uIStr, String initialMtxVal, ObjectReader input) throws Exception {

		ArrayList<String> decodedPattern = new ArrayList<String>();
		String viterbiPos = "";
		ViterbiMostLikelyCalc vmc1 = new ViterbiMostLikelyCalc();
		HashMap<String, String> posMatrix = vmc1.PosABMatrix(input);
		vmc1.PosAMatrix(input);
		
		decodedPattern.add(initialMtxVal); //DT//INS//EVT

		while (!decodedPattern.contains(Consts.DOT_CONSTANT)) {
			ArrayList<String> nxtPosList = new ArrayList<String>();
			
			
			String currPos = decodedPattern.get(decodedPattern.size() - 1);
			nxtPosList = filterNxtBestPos().get(currPos);
			if (nxtPosList != null) {
				ArrayList<String> nxtPosSplit1 = null;
				
				
				nxtPosSplit1 = tSplitList(nxtPosList, uIStr);

				for (String str:nxtPosSplit1) {
					ArrayList<String> decodedPatternList = null;
					decodedPatternList = decodePos(str);
					for (String str1:decodedPatternList) {
						String lastPos = decodedPattern.get(decodedPattern.size() - 1);
						viterbiPos = posMatrix.get(lastPos);
						String lastPosViterbi = compareGrmrViterbi(str1, viterbiPos);
						decodedPattern.add(lastPosViterbi);
					}
				}
			} else {
				decodedPattern.add(Consts.DOT_CONSTANT);
			}
		}
		return decodedPattern;
	}

	public static ArrayList<String> tSplitList(ArrayList<String> nxtPosList, String uIStr) {

		HashMap<String, ArrayList<String>> splitPosMap = new HashMap<String, ArrayList<String>>();

		for (String str:nxtPosList) {
			ArrayList<String> nxtPosSplit = new ArrayList<String>();
			if (str.contains("(") && str.contains(")")) {
				String[] secPartsBracket = str.split("\\(");
				String key = secPartsBracket[1];
				key = key.replaceAll("\\)", "");
				boolean b = key.equalsIgnoreCase(uIStr + "$1");
				//System.out.println("b:: " + b);
				/*
				 * if(b) { uIStr = uIStr+"$1"; } boolean b1 =
				 * key.equalsIgnoreCase(uIStr+"$2"); if(b1) {
				 * //System.out.println(); uIStr = uIStr+"$2"; }
				 */
				String[] val = secPartsBracket[0].split("%");
				for (int a1 = 0; a1 < val.length; a1++) {
					nxtPosSplit.add(val[a1]);
				}
				splitPosMap.put(key, nxtPosSplit);
			} else {
				String[] val = str.split("%");
				for (int a1 = 0; a1 < val.length; a1++) {
					nxtPosSplit.add(val[a1]);
				}
				splitPosMap.put(Consts.DEFAULT_CONSTANT, nxtPosSplit);
			}
		}
		//System.out.println("splitPosMap:: " + splitPosMap);
		ArrayList<String> nxtPosSplit1 = new ArrayList<String>();
		//System.out.println("uIStr is:: " + uIStr);
		if (splitPosMap.containsKey(uIStr)) {
			//System.out.println("splitPosMap contains:: " + uIStr);
			nxtPosSplit1 = splitPosMap.get(uIStr);
			// uIStr="DG";
			//System.out.println("value found is:: " + nxtPosSplit1);
		} else {
			nxtPosSplit1 = splitPosMap.get("DFLT");
		}
		// System.out.println("nxtPosSplit1::"+nxtPosSplit1);
		return nxtPosSplit1;

	}

	public static ArrayList<String> decodePos(String decodePos) throws IOException {

		ArrayList<String> decodedPosList = new ArrayList<String>();
		ArrayList<String> hyrbidPos = new ArrayList<String>();
		hyrbidPos = hyrbidPos();

		if (hyrbidPos.contains(decodePos)) {
			decodedPosList = filterNxtBestPos().get(decodePos);
			for (int b = 0; b < decodedPosList.size(); b++) {
				if (decodedPosList.get(b).contains("%")) {
					String[] secParts = decodedPosList.get(b).split("\\%");
					decodedPosList.remove(b);
					for (int b1 = 0; b1 < secParts.length; b1++) {
						decodedPosList.add(secParts[b1]);
					}

				}
				decodePos(decodedPosList.get(b));
			}
		} else {
			decodedPosList.add(decodePos);
		}
		return decodedPosList;
	}

	public static ArrayList<String> hyrbidPos() throws IOException {
		ArrayList<String> hyrbidPosSplit = new ArrayList<String>();
		ArrayList<String> hyrbidPos1 = new ArrayList<String>();
		hyrbidPos1 = filterNxtBestPos().get(hybridPos);
		for (int b1 = 0; b1 < hyrbidPos1.size(); b1++) {
			String[] secParts = hyrbidPos1.get(b1).split("\\%");
			for (int b2 = 0; b2 < secParts.length; b2++) {
				hyrbidPosSplit.add(secParts[b2]);
			}
		}
		return hyrbidPosSplit;
	}

	public static String compareGrmrViterbi(String nextpos, String viterbiPos) throws Exception {
		//String viterbiPos = "";

		try {
			//ViterbiMostLikelyCalc vmc1 = new ViterbiMostLikelyCalc();
			//viterbiPos = vmc1.PosABMatrix(input).get(lastPos);
			boolean check = viterbiPos.equalsIgnoreCase(nextpos);
			if (check) {
				return viterbiPos;
			} else {
				return nextpos;
			}
		} catch (NullPointerException npe) {
			return nextpos;
		}
	}

	public static String getValueAt(String inputVal, int seqNo) throws Exception {
		String initMatxVal = "";

		switch (seqNo) {
		case 1:
			switch (inputVal) {
			case Consts.SBJ_CONSTANT:
				initMatxVal = Consts.DETERMINANT_CONSTANT;
				return initMatxVal;
			case Consts.EVT_ST_DT_CONSTANT:
				initMatxVal = Consts.CONJ_CONSTANT;
				return initMatxVal;
			case Consts.EVNT_CONSTANT:
				initMatxVal = Consts.EVNT_CONSTANT;
				return initMatxVal;
			}
		case 2:
			switch (inputVal) {
			case Consts.DRUG_CONSTANT:
				initMatxVal = Consts.DETERMINANT_CONSTANT;
				return initMatxVal;
			}
		case 3:
			switch (inputVal) {
			case Consts.EVT_HIST_ST_DT_CONSTANT:
				initMatxVal = Consts.DETERMINANT_CONSTANT;
				return initMatxVal;
			case Consts.ROUT_ADMN_CONSTANT:
				initMatxVal = Consts.CONJ_CONSTANT;
				return initMatxVal;

			}

		}
		//System.out.println("initMatxVal::" + initMatxVal);
		return initMatxVal;

	}
	
	public static HashMap<String, ArrayList<String>> filterNxtBestPos() throws IOException{
		Properties prop = new Properties();
		Utility utility = new Utility();
		prop= utility.load();
		BufferedReader reader = new BufferedReader(
				new FileReader(prop.getProperty("res_location")+prop.getProperty("rules")));
		String line = reader.readLine();
		HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
		
		while ((line = reader.readLine()) != null) {
			String[] parts = line.split(";");
			String scSplit;
			for (int i = 0; i < parts.length; i++) {
				scSplit = parts[i];
				String[] secParts = scSplit.split(":");
				String secPartsKey = secParts[0];
				String secPartsValue = secParts[1];
				secPartsValue = secPartsValue.replaceAll("\\{", "").replaceAll("\\}","");
				String[] secParts2 = secPartsValue.split("\\|");
				ArrayList<String> values = new ArrayList<String>();
				for (int j = 0; j < secParts2.length; j++) {
					values.add(secParts2[j]);
				}
				map.put(secPartsKey, values);
				
			}
		}
		reader.close();
		//System.out.println("map: "+map);
		return map;
		}

}
