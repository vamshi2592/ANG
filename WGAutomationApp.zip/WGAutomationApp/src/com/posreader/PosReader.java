package com.posreader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.collections15.Bag;
import org.apache.commons.collections15.bag.HashBag;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.pos.Pos;
import com.wga.wg.util.ObjectReader;
import com.wga.wg.util.Utility;

import Jama.Matrix;

public class PosReader {

	private static final Pos DT = null;

	private final Log log = LogFactory.getLog(getClass());
	
	Properties prop = new Properties();
	Utility utility = new Utility();

	private String dataFilesLocation;
	private String wordDictionaryLocation;
	private boolean debug;

	private Bag<String> inputLayerCounts = new HashBag<String>();
	private Bag<String> hiddenLayerCounts = new HashBag<String>();
	private Map<String, Double[]> wordPosMap = new HashMap<String, Double[]>();

	private Matrix inputLayer;
	private Matrix hiddenLayerWts;
	private Matrix confusionWts;
	private List<String> words;

	public void setDataFilesLocation(String dataFilesLocation) {
		this.dataFilesLocation = dataFilesLocation;
	}

	public void setWordDictionaryLocation(String wordDictionaryLocation) {
		this.wordDictionaryLocation = wordDictionaryLocation;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	public void read(ObjectReader inputVal) throws Exception {
	    utility.learn(inputVal);
		prop = utility.load();
		String res_Path = prop.getProperty("res_location");
		File location = new File(res_Path+prop.getProperty("build_learn"));
		File[] inputs;
		if (location.isDirectory()) {
			inputs = location.listFiles();
		} else {
			inputs = new File[] { location };
		}
		int currfile = 0;
		int totfiles = inputs.length;
		for (File input : inputs) {
			currfile++;
			//log.info("Processing file (" + currfile + "/" + totfiles + "): " + input.getName());
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(input)));
			String line;
			while ((line = reader.readLine()) != null) {
				if (StringUtils.isEmpty(line)) {
					continue;
				}
				StringTokenizer tok = new StringTokenizer(line, " ");
				int wordIndex = 0;
				Pos prevPos = null;
				while (tok.hasMoreTokens()) {
					String taggedWord = tok.nextToken();
					String[] wordTagPair = StringUtils.split(StringUtils.lowerCase(StringUtils.trim(taggedWord)), "_");
					if (wordTagPair.length != 2) {
						continue;
					}
					Pos pos = Pos.fromCrpsTag(wordTagPair[1]);
					if (!wordPosMap.containsKey(wordTagPair[0])) {
						// create an entry
						Double[] posProbs = new Double[Pos.values().length];
						for (int i = 0; i < posProbs.length; i++) {
							posProbs[i] = new Double(0.0D); // all probs are 0.0
						}
						// key&value -> word, [5 probs of each tag]
						wordPosMap.put(wordTagPair[0], posProbs);
					}
					Double[] posProbs = wordPosMap.get(wordTagPair[0]);
					posProbs[pos.ordinal()] += 1.0D;
					
					//only last prob increased by 1.0
					wordPosMap.put(wordTagPair[0], posProbs); 
					
					if (wordIndex == 0) {
						// first word, update InputLayer Counts
						// adds pos tag for first word and updates total no of each pos
						inputLayerCounts.add(pos.name()); 
						
					} else {
						hiddenLayerCounts.add(StringUtils.join(new String[] { prevPos.name(), pos.name() }, ":"));
						
					}
					prevPos = pos;
					wordIndex++;
				}
			}
			reader.close();
		}
		
		// normalize counts to probabilities
		int numPos = Pos.values().length;
		// compute pi
		inputLayer = new Matrix(numPos, 1);
		for (int i = 0; i < numPos; i++) {
			inputLayer.set(i, 0, inputLayerCounts.getCount((Pos.values()[i]).name()));
		}
		inputLayer = inputLayer.times(1 / inputLayer.norm1());
		// compute a
		hiddenLayerWts = new Matrix(numPos, numPos);
		for (int i = 0; i < numPos; i++) {
			for (int j = 0; j < numPos; j++) {
				hiddenLayerWts.set(i, j, hiddenLayerCounts.getCount(
						StringUtils.join(new String[] { (Pos.values()[i]).name(), (Pos.values()[j]).name() }, ":")));
			}
		}
		// compute b
		int numWords = wordPosMap.size();
		words = new ArrayList<String>();
		words.addAll(wordPosMap.keySet());
		confusionWts = new Matrix(numPos, numWords);
		for (int i = 0; i < numPos; i++) {
			for (int j = 0; j < numWords; j++) {
				String word = words.get(j);
				confusionWts.set(i, j, wordPosMap.get(word)[i]);
			}
		}
		// normalize across rows for hiddenLayer Weights and Confusion Weights (sum of cols in each row == 1.0)
		for (int i = 0; i < numPos; i++) {
			double rowSumHiddenLayerWts = 0.0D;
			for (int j = 0; j < numPos; j++) {
				rowSumHiddenLayerWts += hiddenLayerWts.get(i, j);
			}
			for (int j = 0; j < numPos; j++) {
				hiddenLayerWts.set(i, j, (hiddenLayerWts.get(i, j) / rowSumHiddenLayerWts));
			}
			double rowSumConfusionWts = 0.0D;
			for (int j = 0; j < numWords; j++) {
				rowSumConfusionWts += confusionWts.get(i, j);
			}
			for (int j = 0; j < numWords; j++) {
				confusionWts.set(i, j, (confusionWts.get(i, j) / rowSumConfusionWts));
			}
		}
		// write out word dictionary for later use
		//writeDictionary();
		
		System.out.println("*********Input Layer Weights*********");
		inputLayer.print(10, 6);
		
		System.out.println("*********Hidden Layer Weights*********");
		hiddenLayerWts.print(10, 6);
		
		System.out.println("*********Confusion Weights*********");
		//confusionWts.print(10, 6);
		
		System.out.println("*********hidden boolean Weights*********");
		//getHiddenLayerWtsbool1().print(10, 6);
	}
	


	public List<String> getWords() {
		return words;
	}

	public double[] getInputLayer() {
		double[] inputLayerWt = new double[inputLayer.getRowDimension()];
		for (int i = 0; i < inputLayerWt.length; i++) {
			inputLayerWt[i] = inputLayer.get(i, 0);
		}
		return inputLayerWt;
	}

	public double[][] getHiddenLayerWts() {
		double[][] hiddenWt = new double[hiddenLayerWts.getRowDimension()][hiddenLayerWts.getColumnDimension()];
		for (int i = 0; i < hiddenLayerWts.getRowDimension(); i++) {
			for (int j = 0; j < hiddenLayerWts.getColumnDimension(); j++) {
				hiddenWt[i][j] = hiddenLayerWts.get(i, j);
			}
		}
		return hiddenWt;
	}

	public double[][] getConfusionWts() {
		double[][] confWt = new double[confusionWts.getRowDimension()][confusionWts.getColumnDimension()];
		for (int i = 0; i < confusionWts.getRowDimension(); i++) {
			for (int j = 0; j < confusionWts.getColumnDimension(); j++) {
				confWt[i][j] = confusionWts.get(i, j);
			}
		}
		return confWt;
	}
	
	public Matrix getHiddenLayerWtsbool1() {
		int rows = hiddenLayerWts.getRowDimension();
		int cols = hiddenLayerWts.getColumnDimension();
		Matrix matrix1 = new Matrix(rows, cols);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				matrix1.set(i, j, hiddenLayerWts.get(i, j));
				/*if(hiddenLayerWts.get(i, j) == 0){
					matrix1.set(i, j, 0);
				}
				else{
					matrix1.set(i, j, 1);
				}*/
			}
		}
		return matrix1;
	}
	
	private void writeDictionary() throws Exception {
		String wordDictionaryLocation = "resources/wordDictionaryLocation.txt";
		FileWriter dictWriter = new FileWriter(wordDictionaryLocation);
		for (String word : words) {
			dictWriter.write(word + "\n");
		}
		dictWriter.flush();
		dictWriter.close();
	}
	
	
	public void read2(ObjectReader inputVal) throws Exception {
		/*ObjectReader inputVal = new ObjectReader();
		inputVal.setDate("Jan");
		inputVal.setDrughistoryname("divatin");
		inputVal.setDrugname("crocin");
		inputVal.setEvent("diabetes");
		inputVal.setEventDrugs("ibuprofen");
		inputVal.setAge("25");*/
	    utility.learn(inputVal);
		prop = utility.load();
		String res_Path = prop.getProperty("res_location");
		File location = new File(res_Path+prop.getProperty("build_learn"));
		File[] inputs;
		if (location.isDirectory()) {
			inputs = location.listFiles();
		} else {
			inputs = new File[] { location };
		}
		int currfile = 0;
		int totfiles = inputs.length;
		for (File input : inputs) {
			currfile++;
			//log.info("Processing file (" + currfile + "/" + totfiles + "): " + input.getName());
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(input)));
			String line;
			while ((line = reader.readLine()) != null) {
				if (StringUtils.isEmpty(line)) {
					continue;
				}
				StringTokenizer tok = new StringTokenizer(line, " ");
				int wordIndex = 0;
				Pos prevPos = null;
				while (tok.hasMoreTokens()) {
					String taggedWord = tok.nextToken();
					String[] wordTagPair = StringUtils.split(StringUtils.lowerCase(StringUtils.trim(taggedWord)), "_");
					if (wordTagPair.length != 2) {
						continue;
					}
					Pos pos = Pos.fromCrpsTag(wordTagPair[1]);
					if (!wordPosMap.containsKey(wordTagPair[0])) {
						// create an entry
						Double[] posProbs = new Double[Pos.values().length];
						for (int i = 0; i < posProbs.length; i++) {
							posProbs[i] = new Double(0.0D); // all probs are 0.0
						}
						// key&value -> word, [5 probs of each tag]
						wordPosMap.put(wordTagPair[0], posProbs);
					}
					Double[] posProbs = wordPosMap.get(wordTagPair[0]);
					posProbs[pos.ordinal()] += 1.0D;
					
					//only last prob increased by 1.0
					wordPosMap.put(wordTagPair[0], posProbs); 
					
					if (wordIndex == 0) {
						// first word, update InputLayer Counts
						// adds pos tag for first word and updates total no of each pos
						inputLayerCounts.add(pos.name()); 
						
					} else {
						hiddenLayerCounts.add(StringUtils.join(new String[] { prevPos.name(), pos.name() }, ":"));
						
					}
					prevPos = pos;
					wordIndex++;
				}
			}
			reader.close();
		}
		
		// normalize counts to probabilities
		int numPos = Pos.values().length;
		// compute pi
		inputLayer = new Matrix(numPos, 1);
		for (int i = 0; i < numPos; i++) {
			inputLayer.set(i, 0, inputLayerCounts.getCount((Pos.values()[i]).name()));
		}
		inputLayer = inputLayer.times(1 / inputLayer.norm1());
		// compute a
		hiddenLayerWts = new Matrix(numPos, numPos);
		for (int i = 0; i < numPos; i++) {
			for (int j = 0; j < numPos; j++) {
				hiddenLayerWts.set(i, j, hiddenLayerCounts.getCount(
						StringUtils.join(new String[] { (Pos.values()[i]).name(), (Pos.values()[j]).name() }, ":")));
			}
		}
		// compute b
		int numWords = wordPosMap.size();
		words = new ArrayList<String>();
		words.addAll(wordPosMap.keySet());
		confusionWts = new Matrix(numPos, numWords);
		for (int i = 0; i < numPos; i++) {
			for (int j = 0; j < numWords; j++) {
				String word = words.get(j);
				confusionWts.set(i, j, wordPosMap.get(word)[i]);
			}
		}
		// normalize across rows for hiddenLayer Weights and Confusion Weights (sum of cols in each row == 1.0)
		for (int i = 0; i < numPos; i++) {
			double rowSumHiddenLayerWts = 0.0D;
			for (int j = 0; j < numPos; j++) {
				rowSumHiddenLayerWts += hiddenLayerWts.get(i, j);
			}
			for (int j = 0; j < numPos; j++) {
				hiddenLayerWts.set(i, j, (hiddenLayerWts.get(i, j) / rowSumHiddenLayerWts));
			}
			double rowSumConfusionWts = 0.0D;
			for (int j = 0; j < numWords; j++) {
				rowSumConfusionWts += confusionWts.get(i, j);
			}
			for (int j = 0; j < numWords; j++) {
				confusionWts.set(i, j, (confusionWts.get(i, j) / rowSumConfusionWts));
			}
		}
	}

}
