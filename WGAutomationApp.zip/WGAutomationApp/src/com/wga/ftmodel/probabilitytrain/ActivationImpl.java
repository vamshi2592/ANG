package com.wga.ftmodel.probabilitytrain;

//TODO : Add Logger
//TODO : refine naming conversion
//TODO : remove main()
public class ActivationImpl {

	public static void main(String[] args) {

		try {

			Activation activation = new Activation();
			activation.biWt();
			activation.trioWt();
			activation.quadWt();

		} catch (Exception e) {
			
		}
	}

}
