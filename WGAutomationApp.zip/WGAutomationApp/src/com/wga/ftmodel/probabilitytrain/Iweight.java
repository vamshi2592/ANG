package com.wga.ftmodel.probabilitytrain;

public interface Iweight {
	
	

}
