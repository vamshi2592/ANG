package com.wga.ftmodel.probabilitytrain;

import com.wga.ftmodel.probability.ComputeWeight;
import com.wga.ftmodel.probability.Probability;

//TODO : Add Logger
//TODO : refine naming conversion
public class Activation {

	ComputeWeight computeWeight = new ComputeWeight();

	// TODO: read the sentence from the input file(wttrainset.properties)

	public void biWt() {

		Probability prob1 = new Probability(
				"The patient has been reported with breathing problem on June. The patient continued to have breathing problem since June. The patient was experienced with breathing problem in june",
				1);
		prob1.generateWt();

	}

	public void trioWt() {

		Probability prob1 = new Probability(
				"The patient has been reported with breathing problem on June. The patient continued to have breathing problem since June. The patient was experienced with breathing problem in june",
				3);
		prob1.generateWt();

	}

	public void quadWt() {

		Probability prob1 = new Probability(
				"The patient has been reported with breathing problem on June. The patient continued to have breathing problem since June. The patient was experienced with breathing problem in june",
				4);
		prob1.generateWt();

	}

}
