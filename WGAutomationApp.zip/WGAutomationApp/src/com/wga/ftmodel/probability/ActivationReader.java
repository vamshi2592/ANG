package com.wga.ftmodel.probability;

//TODO : Add Logger
//TODO reader to read from file and pass each sentence to Activation class
public class ActivationReader {
	
	

}
