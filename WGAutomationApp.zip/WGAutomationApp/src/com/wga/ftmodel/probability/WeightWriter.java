package com.wga.ftmodel.probability;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

//TODO : Add Logger
//TODO : refine naming conversion
public class WeightWriter {

	public void writer(String key, String nxtword, int cnt) {
		try {

			String fileName = "resources/actiweight.crp";
			FileOutputStream outputStream = new FileOutputStream(fileName, true);
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
			BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

			bufferedWriter.write("" + key + "," + nxtword + ":" + cnt);
			bufferedWriter.newLine();

			bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
