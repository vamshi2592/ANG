package com.wga.ftmodel.probability;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//TODO : Add Logger
//TODO : refine naming conversion
public class Probability {

	private String words[]; // Initial Text
	private HashMap<String, List<String>> wMap; // weight Map
	private int counter = 0; // Counter value
	private int n = 2; // Value for wt default 2

	/**
	 * Constructor Text parsing and splitting
	 * 
	 * @param text
	 *            , input text
	 * @param n
	 *            , wt value [Default = 2]
	 */
	public Probability(String text, int n) {

		if (text == null || text.length() == 0)
			throw new IllegalArgumentException("Not valid text inserted");

		text.toLowerCase().replaceAll("[.,;]", "");
		words = text.split(" ");
		wMap = new HashMap<String, List<String>>();

		if (n > 2)
			this.n = n;
	}

	/**
	 * Method to generate weights
	 * 
	 * @return Map with weight - Default n = 2
	 */
	public Map<String, List<String>> generateWt() {

		for (int i = 0; i <= words.length - n; i++) {
			counter = 1;
			StringBuilder sb = new StringBuilder();
			int j = 0;
			while (j < n - 1) {
				//System.out.println("words[i + j]::" + words[i + j]);
				sb.append(words[i + j].trim());
				j++;
				if (j < n - 1)
					sb.append(" ");
				// System.out.println(sb.toString());
			}
			String key = sb.toString();
			
			if (!wMap.containsKey(key)) {
				ArrayList<String> list = new ArrayList<>();

				list.add(words[i + j]);

				wMap.put(key, list);

			} else {

				
				List<String> list = wMap.get(key);
				if (list.contains(words[i + j]))

					counter++;
				list.add(words[i + j]);

			}
			// System.out.println("(( " + key + "," + words[i + j] + ")" +
			// ","+counter +")");
			// read(key);
			WeightWriter wr = new WeightWriter();
			wr.writer(key, words[i + j], counter);

		}

		return wMap;

	}

}
