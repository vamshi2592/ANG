package com.wga.wg.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.Stream;

import org.json.JSONException;

public class StructureTemplate {
	
	Properties prop = new Properties();
	Utility utility = new Utility();
	
	public String getTemplate() throws IOException{
		
		prop= utility.load();
		//String fileName = prop.getProperty("structure");
		
		// String delimiter = ":";
	        Map<Integer, String> map = new HashMap<>();
	        String       value= "";
	        Integer       randomKey;

	       /* try(Stream<String> lines = Files.lines(Paths.get(fileName),
	                StandardCharsets.UTF_8)){
	            lines.filter(line -> line.contains(delimiter)).forEach(
	                line -> map.putIfAbsent(line.split(delimiter)[0], line.split(delimiter)[1])
	            );
	         */   
	            try {
					map = utility.getEmissionSequence();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            
	            Random       random    = new Random();
	            List<Integer> keys      = new ArrayList<Integer>(map.keySet());
	            randomKey = keys.get( random.nextInt(keys.size()) );
	            value     = map.get(randomKey);
	          
	       // }
	        
	      // ;
	        return value;

	}

}
