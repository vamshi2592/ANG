package com.wga.wg.util;

public class ObjectReader {
	
	private String reporter;
	private String age="";
	private String event;
	private String date;
	private String eventDrugs="";
	private String seriousOfEvt="";
	private String route="";
	private String drugname="";
	private String drughistoryname="";
	private String eventhistory="";
	private String eventhistorydate="";
	
	private String generatedSentence;
	
	public String getGeneratedSentence() {
		return generatedSentence;
	}
	public void setGeneratedSentence(String generatedSentence) {
		this.generatedSentence = generatedSentence;
	}
	public String getReporter() {
		return reporter;
	}
	public void setReporter(String reporter) {
		this.reporter = reporter;
	}
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEventDrugs() {
		return eventDrugs;
	}
	public void setEventDrugs(String eventDrugs) {
		this.eventDrugs = eventDrugs;
	}
	public String getSeriousOfEvt() {
		return seriousOfEvt;
	}
	public void setSeriousOfEvt(String seriousOfEvt) {
		this.seriousOfEvt = seriousOfEvt;
	}
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public String getDrugname() {
		return drugname;
	}
	public void setDrugname(String drugname) {
		this.drugname = drugname;
	}
	public String getDrughistoryname() {
		return drughistoryname;
	}
	public void setDrughistoryname(String drughistoryname) {
		this.drughistoryname = drughistoryname;
	}
	public String getEventhistory() {
		return eventhistory;
	}
	public void setEventhistory(String eventhistory) {
		this.eventhistory = eventhistory;
	}
	public String getEventhistorydate() {
		return eventhistorydate;
	}
	public void setEventhistorydate(String eventhistorydate) {
		this.eventhistorydate = eventhistorydate;
	}

}
