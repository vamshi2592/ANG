package com.wga.wg.util;

public final class Consts {
	
	public static final String DRUG_CONSTANT = "DG";
	public static final String EVT_ST_DT_CONSTANT = "ESD";
	public static final String SBJ_CONSTANT = "SBJ";
	public static final String EVNT_CONSTANT = "EVT";
	public static final String EVT_HIST_ST_DT_CONSTANT = "EVHS";
	public static final String ROUT_ADMN_CONSTANT = "ROA";
	public static final String DETERMINANT_CONSTANT = "DT";
	public static final String CONJ_CONSTANT = "INS";
	public static final String DEFAULT_CONSTANT = "DFLT";
	public static final String DOT_CONSTANT = "DOT";
	public static final String CUSTOM_CONSTANT = "HP";
		
}
