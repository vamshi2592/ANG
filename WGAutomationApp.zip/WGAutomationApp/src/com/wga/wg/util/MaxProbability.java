package com.wga.wg.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class MaxProbability {
	
	String fileName = "D:/NLG_Project/src/prediction/predCorpus.txt";
	
	HashMap<String, Integer> map = new HashMap<String, Integer>();
	String line;
	{
	File file = new File(fileName);	    
	try{
	BufferedReader reader = new BufferedReader(new InputStreamReader
			(new FileInputStream(file),"UTF8"));
    
	//Code to the corpus data as key value pairs
    while ((line = reader.readLine()) != null)
    {
        String[] parts = line.split(":", 2);
        if (parts.length >= 2)
        {
            String key = parts[0];
            String value = parts[1];
            map.put(key, Integer.valueOf(value));                
            //System.out.println("map.values()::"+map.values());
            
        } else {
           
        }
    }
    
    
    
    // Code to read the max value from the Map
    int maxValueInMap=(Collections.max(map.values()));  // This will return max value in the Hashmap
    System.out.println("maxValueInMap::"+maxValueInMap);  
    for (Entry<String, Integer> entry : map.entrySet()) {  // Itrate through hashmap
        if (entry.getValue()==maxValueInMap) {
            System.out.println("entry kay max::"+entry.getKey());     // Print the key with max value
        }
    }
    reader.close();
	} catch(Exception e){
		
		
	}
   
   
}

}
