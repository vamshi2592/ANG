package com.wga.wg.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.posautomation.CreateTagsDict;

public class Utility {

	private final String SUBJECT_POS = "SBJ";
	private final String EVT_POS = "EVT";
	private final String EVT_ST_DT_POS = "MD";
	private final String DRG_NM_POS = "DG";
	private final String DRG_HIS_POS = "DGH";
	private final String DRG_EVH_POS = "EVH";
	private final String SBJ_AGENO_POS = "AGENO";

	public Properties load() {

		Properties prop = new Properties();
		InputStream input = null;

		try {

			// String filename =
			// "D:/NLGWorspace_New/WGAutomationApp/resources/config.properties";
			input = getClass().getClassLoader().getResourceAsStream("config.properties");
			// input = new FileInputStream(filename);

			// load a properties file from class path, inside static method
			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return prop;
	}

	public void learn(ObjectReader inputRdr) throws IOException {
		Properties prop = new Properties();
		prop = load();
		String res_Path = prop.getProperty("res_location");
		String wordDictionaryLocation = res_Path + prop.getProperty("learn");
		FileWriter dictWriter = new FileWriter(wordDictionaryLocation, true);
		BufferedReader dicreader = new BufferedReader(
				new InputStreamReader(new FileInputStream(wordDictionaryLocation)));
		
		String drugname = inputRdr.getDrugname();
		String drughistoryname = inputRdr.getDrughistoryname();
		String eventhistory = inputRdr.getEventhistory();
		String age = inputRdr.getAge();
		StringBuilder taggerWord = new StringBuilder();
		String ln = taggerWord.toString();
loop1:  if (drugname != null || drugname != "") {
			while ((ln = dicreader.readLine()) != null) {
				String[] parts = ln.split("_", 2);
				String entryVal = parts[0];
				if (entryVal.equalsIgnoreCase(drugname)) {
					break loop1;
				}
			}
			taggerWord = taggerWord.append("\n");
			taggerWord = taggerWord.append(drugname).append("_").append(DRG_NM_POS);
		}
loop2:  if (drughistoryname != null || drughistoryname != "") {
			while ((ln = dicreader.readLine()) != null) {
				String[] parts = ln.split("_", 2);
				String entryVal = parts[0];
				if (entryVal.equalsIgnoreCase(drughistoryname)) {
					break loop2;
				}
			}
			taggerWord = taggerWord.append("\n");
			taggerWord = taggerWord.append(drughistoryname).append("_").append(DRG_HIS_POS);
		}
loop3:  if (eventhistory != null || eventhistory != "") {
			while ((ln = dicreader.readLine()) != null) {
				String[] parts = ln.split("_", 2);
				String entryVal = parts[0];
				if (entryVal.equalsIgnoreCase(eventhistory)) {
					break loop3;
				}
			}
			taggerWord = taggerWord.append("\n");
			taggerWord = taggerWord.append(eventhistory).append("_").append(DRG_EVH_POS);
		}
loop4:  if (age != null || age != "") {
			while ((ln = dicreader.readLine()) != null) {
				String[] parts = ln.split("_", 2);
				String entryVal = parts[0];
				if (entryVal.equalsIgnoreCase(age)) {
					break loop4;
				}
			}
			taggerWord = taggerWord.append("\n");
			taggerWord = taggerWord.append(age).append("_").append(SBJ_AGENO_POS);
		}
		
		
		dictWriter.write(taggerWord.toString());
		dictWriter.flush();
		dictWriter.close();
		dicreader.close();

	}

	public Map<Integer, String> getEmissionSequence() throws FileNotFoundException, IOException, JSONException {
		Map<Integer, String> map = new HashMap<>();

		Properties prop = new Properties();
		prop = load();
		String emission_Seq_Path = prop.getProperty("emission_seq");
		String jsonData = readFile(emission_Seq_Path);
		JSONObject jobj = new JSONObject(jsonData);
		JSONArray resultArr = new JSONArray(jobj.getJSONArray("result").toString());

		for (int i = 0; i < resultArr.length(); i++) {

			JSONObject predictionObj = new JSONObject(resultArr.getString(i));
			int w = 0;
			for (int jj = 0; jj < predictionObj.length(); jj++) {

				String predictionStr = "prediction" + jj;

				JSONArray predictionArr = new JSONArray();
				predictionArr = predictionObj.getJSONArray(predictionStr);

				JSONObject sequenceObj = new JSONObject(predictionArr.getString(0));
				StringBuilder sb = new StringBuilder();
				for (int k = 0; k < sequenceObj.length(); k++) {
					String seqStr = "sequence" + k;

					JSONArray seqArr = new JSONArray();
					seqArr = sequenceObj.getJSONArray(seqStr);

					for (int kk = 0; kk < seqArr.length(); kk++) {
						// System.out.println("kk: " + kk);
						// System.out.println("seqArr.length(): " +
						// seqArr.length());
						JSONObject stateObj = seqArr.getJSONObject(kk);
						String stateValue = stateObj.optString("state");
						// System.out.println("stateValue: " + stateValue);
						sb.append(stateValue);

						sb.append("~");

						// System.out.println("sb: " + sb);

					}
				}
				
				w++;

				map.put(w, sb.toString());
				// System.out.println("map::" + map.size());
			}

		}
		return map;

	}

	public static String readFile(String filename) {
		String result = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			result = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}