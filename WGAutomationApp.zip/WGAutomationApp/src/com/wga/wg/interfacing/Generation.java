package com.wga.wg.interfacing;

public class Generation {

}
