package com.wga.wg.interfacing;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.posautomation.PosModelImpl;
import com.wga.wg.util.ObjectReader;

public class GenerationImpl{
	
	//public static void main(String[] args) throws Exception {
	public String Call(ObjectReader inputRdr,String contextPath) throws Exception {
    
		StringBuilder predictedWts = new StringBuilder();
		
        PosModelImpl posmodel = new PosModelImpl();
        String capPredictedWts = "", match;
       try{
        predictedWts =  posmodel.predict(inputRdr, contextPath);        
        //System.out.println("predictedWts in try:: "+predictedWts);
        String sentence = predictedWts.toString();
        Pattern pattern = Pattern.compile("[^\\.]*\\.\\s*");
        Matcher matcher = pattern.matcher(sentence);
       
        while(matcher.find()){
        	//System.out.println("in matcher while loop::");
            match = matcher.group();
            capPredictedWts += Character.toUpperCase(match.charAt(0)) + match.substring(1);
            if(!capPredictedWts.equalsIgnoreCase(".")){
            	capPredictedWts = " "+capPredictedWts;
			}
            else{
            	capPredictedWts = capPredictedWts.trim();
            }
        }
        //capPredictedWts = predictedWts.toString();
        //System.out.println("capPredictedWts in try:: "+capPredictedWts);
        } catch(IllegalArgumentException n){
        	predictedWts.append("Encountered new word[s],sufficient training has to be done...");
        	capPredictedWts = predictedWts.toString();
        	n.printStackTrace();
        	
        }
       System.out.println("capPredictedWts::"+capPredictedWts);
		return capPredictedWts;
	}


}
