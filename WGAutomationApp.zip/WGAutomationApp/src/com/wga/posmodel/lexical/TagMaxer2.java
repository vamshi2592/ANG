package com.wga.posmodel.lexical;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

//import edu.stanford.nlp.tagger.maxent.MaxentTagger;

public class TagMaxer2 {
	  public static void main(String[] args) throws Exception {
		    
	      /*   MaxentTagger tagger = new MaxentTagger( 
	                     "resources/english-bidirectional-distsim.tagger");
	         
	         HashMap<String, Set<String>> map1 = new HashMap<String, Set<String>>();
	         
	         Scanner input = new Scanner(new File("resources/inputText.txt"));
	           input.useDelimiter("\n");

	           String posOutputFile = "tagged-output2.txt";
	           FileOutputStream fos = new FileOutputStream(posOutputFile);
	           BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	           
	           while(input.hasNext()) {
	               String sentence = input.next();
	               String taggedsentence = tagger.tagString(sentence);
	               System.out.println(taggedsentence);
	               bw.write(taggedsentence);
	               bw.newLine();
	           }
	           bw.close();
	           
	           Scanner input1 = new Scanner(new File("tagged-output2.txt"));
	           input1.useDelimiter(" |\n");
	           String posOutputFile1 = "tagged-token-output2.txt";
	           FileOutputStream fos1 = new FileOutputStream(posOutputFile1);
	           BufferedWriter bw1 = new BufferedWriter(new OutputStreamWriter(fos1));
	           
	           while(input1.hasNext()) {
	               String word = input1.next();
	               System.out.println(word);
	               bw1.write(word);
	               bw1.newLine();
	           }
	           bw1.close();
	           
	           Lexical posTable = new Lexical();
	           map1 = posTable.posmap();
	           System.out.println(map1);
	           
	           String finalcorpus = "resources/final-corpus.txt";
	           FileOutputStream fos2 = new FileOutputStream(finalcorpus);
	           BufferedWriter bw2 = new BufferedWriter(new OutputStreamWriter(fos2));

	           for (String key : map1.keySet())
	           {
	                     bw2.write(key+":"+map1.get(key));
	                     bw2.newLine();
	           }
	           bw2.close();
	  */}
	  
	}



