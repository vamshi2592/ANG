package com.wga.posmodel.lexical;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Lexical {
	
    public HashMap<String, Set<String>> posmap() throws IOException 
   {
     HashMap<String, Set<String>> map = new HashMap<String, Set<String>>();
    
    BufferedReader reader = new BufferedReader(new FileReader("tagged-token-output2.txt"));
    String line;
    int n=0;
     while ((line = reader.readLine()) != null)
     {
         String[] parts = line.split("_", 2);
         if (parts.length >= 2)
         {
             String key = parts[1];
             String value = parts[0];
             
             boolean flag = map.containsKey(key);
             
             if (flag == false){
                 Set<String> al = new HashSet<>();
                 al.add(value);
                 map.put(key, al);
             }
             
             else {
                 map.get(key).add(value);
             }
         } 
         else {
         n++;
             //System.out.println(n+" blank lines ignored"+line);
         }
     }
     reader.close();
           return map;
 }



}
